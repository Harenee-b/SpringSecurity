package com.ons.securitylayerJwt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityLayerJwtApplicationTests {

    @Test
    void contextLoads() {
    }

}
