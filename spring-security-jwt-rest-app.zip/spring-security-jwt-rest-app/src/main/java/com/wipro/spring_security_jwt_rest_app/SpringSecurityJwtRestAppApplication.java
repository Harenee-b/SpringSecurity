package com.wipro.spring_security_jwt_rest_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityJwtRestAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityJwtRestAppApplication.class, args);
	}

}
