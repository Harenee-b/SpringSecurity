package com.wipro.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;


@Controller
public class HelloController {
	

	@GetMapping(value={"/","/home"})
    public String goHome() {
          return "home";
}
	
	@GetMapping(value={"/hello"})
    public String goHello() {
          return "hello";
}
	
	@GetMapping(value={"/login"})
    public String goLogin() {
          return "login";
}

}
